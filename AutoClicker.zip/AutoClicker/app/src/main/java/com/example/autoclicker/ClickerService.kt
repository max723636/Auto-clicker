package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

class ClickerService : AccessibilityService() {

    companion object {
        const val PREFS = "autoclicker"
        const val KEY_INTERVAL = "interval"
        var instance: ClickerService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    private val markers = mutableListOf<TextView>()
    private var panel: LinearLayout? = null
    private var playButton: TextView? = null
    private var speedRow: LinearLayout? = null
    private var speedLabel: TextView? = null
    private var speedSeek: SeekBar? = null
    private var running = false
    private var index = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onDestroy() {
        hideOverlay()
        instance = null
        super.onDestroy()
    }

    // ---------------- Overlay ----------------

    fun showOverlay() {
        if (panel != null) return
        try {
            val p = buildPanel()
            wm.addView(p, params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(120)))
            panel = p
            addMarker()
        } catch (e: Exception) {
            toast("Overlay-Fehler: " + e.message)
        }
    }

    private fun hideOverlay() {
        stopClicking()
        for (m in markers) removeQuietly(m)
        markers.clear()
        panel?.let { removeQuietly(it) }
        panel = null
        playButton = null
        speedRow = null
        speedLabel = null
        speedSeek = null
    }

    private fun removeQuietly(v: View) {
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun params(w: Int, h: Int, x: Int, y: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y
        return lp
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun button(text: String, onClick: () -> Unit = {}): TextView {
        val b = TextView(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun makeDraggable(touchView: View, target: View) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        touchView.setOnTouchListener { _, e ->
            val lp = target.layoutParams as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = e.rawX
                    downY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(target, lp)
                }
            }
            true
        }
    }

    private fun buildPanel(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(6), dp(4), dp(6), dp(4))
        root.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(Color.argb(230, 25, 25, 25))
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val handle = button("≡")
        makeDraggable(handle, root)
        val play = button("Start") { toggleRun() }
        playButton = play
        row.addView(handle)
        row.addView(play)
        row.addView(button("+") { addMarker() })
        row.addView(button("−") { removeMarker() })
        row.addView(button("Tempo") { toggleSpeedRow() })
        row.addView(button("✕") { hideOverlay() })
        root.addView(row)

        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 13f
        label.text = speedText(interval())

        val seek = SeekBar(this)
        seek.max = 100
        seek.progress = toProgress(interval())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putLong(KEY_INTERVAL, toMs(p)).apply()
                label.text = speedText(interval())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val speed = LinearLayout(this)
        speed.orientation = LinearLayout.VERTICAL
        speed.setPadding(dp(8), 0, dp(8), dp(4))
        speed.addView(label)
        speed.addView(seek, LinearLayout.LayoutParams(dp(250), LinearLayout.LayoutParams.WRAP_CONTENT))
        speed.visibility = View.GONE
        root.addView(speed)

        speedRow = speed
        speedLabel = label
        speedSeek = seek
        return root
    }

    private fun toggleSpeedRow() {
        val row = speedRow ?: return
        if (row.visibility == View.VISIBLE) {
            row.visibility = View.GONE
        } else {
            speedSeek?.progress = toProgress(interval())
            speedLabel?.text = speedText(interval())
            row.visibility = View.VISIBLE
        }
    }

    // ---------------- Klickpunkte ----------------

    private fun addMarker() {
        if (running) return
        val n = markers.size + 1
        val size = dp(48)
        val m = TextView(this)
        m.text = n.toString()
        m.textSize = 16f
        m.typeface = Typeface.DEFAULT_BOLD
        m.setTextColor(Color.WHITE)
        m.gravity = Gravity.CENTER
        m.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(190, 229, 57, 53))
            setStroke(dp(2), Color.WHITE)
        }
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2 - size / 2 + ((n - 1) % 5 - 2) * dp(56)
        val y = dm.heightPixels / 2 - size / 2 + ((n - 1) / 5) * dp(56)
        try {
            wm.addView(m, params(size, size, x, y))
        } catch (e: Exception) {
            toast("Punkt konnte nicht gesetzt werden")
            return
        }
        makeDraggable(m, m)
        markers.add(m)
    }

    private fun removeMarker() {
        if (running || markers.isEmpty()) return
        removeQuietly(markers.removeAt(markers.size - 1))
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        for (m in markers) {
            try {
                val lp = m.layoutParams as WindowManager.LayoutParams
                lp.flags = if (touchable) {
                    lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                } else {
                    lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                }
                m.alpha = if (touchable) 1f else 0.5f
                wm.updateViewLayout(m, lp)
            } catch (e: Exception) {
            }
        }
    }

    // ---------------- Klicken ----------------

    private fun toggleRun() {
        if (running) stopClicking() else startClicking()
    }

    private fun startClicking() {
        if (markers.isEmpty()) {
            toast("Zuerst mit + einen Klickpunkt hinzufügen")
            return
        }
        running = true
        index = 0
        playButton?.text = "Stopp"
        setMarkersTouchable(false)
        handler.postDelayed({ clickNext() }, 400)
    }

    private fun stopClicking() {
        if (!running) return
        running = false
        handler.removeCallbacksAndMessages(null)
        playButton?.text = "Start"
        setMarkersTouchable(true)
    }

    private fun clickNext() {
        if (!running) return
        if (markers.isEmpty()) {
            stopClicking()
            return
        }
        val m = markers[index % markers.size]
        index++
        val loc = IntArray(2)
        m.getLocationOnScreen(loc)
        val path = Path()
        path.moveTo(loc[0] + m.width / 2f, loc[1] + m.height / 2f)
        val stroke = GestureDescription.StrokeDescription(path, 0L, 10L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                scheduleNext()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                scheduleNext()
            }
        }
        if (!dispatchGesture(gesture, callback, null)) scheduleNext()
    }

    private fun scheduleNext() {
        if (running) handler.postDelayed({ clickNext() }, interval())
    }

    // ---------------- Tempo (1 ms ... 10 s, logarithmisch) ----------------

    private fun interval(): Long = prefs.getLong(KEY_INTERVAL, 100L).coerceIn(1L, 600000L)

    private fun speedText(ms: Long): String =
        "Pause: " + (if (ms >= 1000) "%.1f s".format(ms / 1000.0) else "$ms ms")

    private fun toProgress(ms: Long): Int = (log10(ms.toDouble()) * 25).roundToInt().coerceIn(0, 100)

    private fun toMs(p: Int): Long = 10.0.pow(p / 25.0).roundToLong()
}
