package com.example.autoclicker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var field: EditText

    private fun prefs() = getSharedPreferences(ClickerService.PREFS, Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById<TextView>(R.id.status)
        field = findViewById<EditText>(R.id.interval)
        field.setText(prefs().getLong(ClickerService.KEY_INTERVAL, 100L).toString())
        field.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val ms = s.toString().toLongOrNull() ?: return
                prefs().edit().putLong(ClickerService.KEY_INTERVAL, ms.coerceIn(1L, 600000L)).apply()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            val service = ClickerService.instance
            if (service == null) {
                Toast.makeText(this, R.string.need_service, Toast.LENGTH_LONG).show()
            } else {
                service.showOverlay()
                moveTaskToBack(true)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val active = ClickerService.instance != null
        status.setText(if (active) R.string.status_on else R.string.status_off)
        val current = prefs().getLong(ClickerService.KEY_INTERVAL, 100L).toString()
        if (field.text.toString() != current) field.setText(current)
    }
}
