# Auto Clicker (Android)

Beliebig viele nummerierte Klickpunkte, Tempo einstellbar (1 ms bis 10 s). Kein Root nötig, nutzt den Bedienungshilfen-Dienst.

## APK bauen
- **Android Studio:** Ordner AutoClicker öffnen, dann Build > Build APK(s). Ergebnis: app/build/outputs/apk/debug/app-debug.apk
- **GitHub (ohne PC):** ZIP in ein neues Repository hochladen und die Datei .github/workflows/build.yml anlegen (Inhalt steht im Chat). Danach unter "Releases" die AutoClicker.apk laden.

## Benutzung
1. App öffnen > "Bedienungshilfe aktivieren" > Auto Clicker einschalten.
2. "Klicker einblenden" tippen.
3. Mit "+" Punkte setzen und verschieben, "Tempo" einstellen, "Start" drücken.
